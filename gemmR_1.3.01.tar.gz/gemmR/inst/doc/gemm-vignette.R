### R code from vignette source 'gemm-vignette.Rnw'

###################################################
### code chunk number 1: setup
###################################################
library(gemmR)
data(culture)
mod <- gemm(murder.rate ~ pasture + gini + gnp, data = culture)


###################################################
### code chunk number 2: gemm-vignette.Rnw:55-56
###################################################
summary(mod)


###################################################
### code chunk number 3: plotting
###################################################
check.mod <- gemm(murder.rate ~ pasture + gini + gnp, data = culture, check.convergence = TRUE)
plot(check.mod)


###################################################
### code chunk number 4: gemm-vignette.Rnw:81-84
###################################################
yhat <- predict(mod, tie.struct = TRUE)
head(yhat)
attr(yhat, "tie.struct")


###################################################
### code chunk number 5: gemm-vignette.Rnw:92-95
###################################################
logLik(mod)
AIC(mod)
BIC(mod)


